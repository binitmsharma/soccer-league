package com.example.soccerleaguescheduler.controller;

import com.example.soccerleaguescheduler.service.ScheduleService;
import com.example.soccerleaguescheduler.service.TeamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.List;

@RestController
public class ScheduleController {

    @Autowired
    private TeamService teamService;

    @Autowired
    private ScheduleService scheduleService;

    @GetMapping("/schedule")
    public List<String> getSchedule(@RequestParam(defaultValue = "false") boolean multipleMatchesPerWeek) throws IOException {
        List<String> teams = teamService.getTeams();
        return scheduleService.generateSchedule(teams, multipleMatchesPerWeek);
    }
}
