package com.example.soccerleaguescheduler.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

@Service
public class ScheduleService {

    @Value("${scheduler.start-date}")
    private String startDateString;

    @Value("${scheduler.break-weeks}")
    private int breakWeeks;

    @Value("${scheduler.match-day}")
    private String matchDay;

    @Value("${scheduler.match-interval-weeks}")
    private int matchIntervalWeeks;

    @Value("${scheduler.match-time}")
    private String matchTime;

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    public List<String> generateSchedule(List<String> teams, boolean multipleMatchesPerWeek) {
        List<String> schedule = new ArrayList<>();
        int numTeams = teams.size();
        List<String[]> firstLeg = new ArrayList<>();
        List<String[]> secondLeg = new ArrayList<>();

        // Generate pairings
        for (int i = 0; i < numTeams - 1; i++) {
            for (int j = i + 1; j < numTeams; j++) {
                firstLeg.add(new String[]{teams.get(i), teams.get(j)});
                secondLeg.add(new String[]{teams.get(j), teams.get(i)});
            }
        }

        LocalDate startDate = LocalDate.parse(startDateString, DATE_FORMATTER);
        LocalDate matchDate = startDate;
        LocalTime matchLocalTime = LocalTime.parse(matchTime);

        // Schedule first leg
        int matchesPerWeek = multipleMatchesPerWeek ? numTeams / 2 : 1;
        for (int i = 0; i < firstLeg.size(); i++) {
            if (i % matchesPerWeek == 0 && i > 0) {
                matchDate = matchDate.plus(matchIntervalWeeks, ChronoUnit.WEEKS);
            }
            schedule.add(String.format("%s %s %s %s", matchDate.format(DATE_FORMATTER), matchLocalTime, firstLeg.get(i)[0], firstLeg.get(i)[1]));
        }

        // Add break
        matchDate = matchDate.plus(breakWeeks, ChronoUnit.WEEKS);

        // Schedule second leg
        for (int i = 0; i < secondLeg.size(); i++) {
            if (i % matchesPerWeek == 0 && i > 0) {
                matchDate = matchDate.plus(matchIntervalWeeks, ChronoUnit.WEEKS);
            }
            schedule.add(String.format("%s %s %s %s", matchDate.format(DATE_FORMATTER), matchLocalTime, secondLeg.get(i)[0], secondLeg.get(i)[1]));
        }

        return schedule;
    }
}
