package com.example.soccerleaguescheduler.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class TeamService {
    //private static final String FILE_PATH = "/mnt/data/soccer_teams.json";
    private static final String FILE_PATH = "src/main/resources/soccer_teams.json";

    public List<String> getTeams() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode rootNode = objectMapper.readTree(new File(FILE_PATH));
        JsonNode teamsNode = rootNode.path("teams");

        List<String> teams = new ArrayList<>();
        for (JsonNode teamNode : teamsNode) {
            String teamName = teamNode.path("name").asText();
            teams.add(teamName);
        }
        return teams;
    }
}
