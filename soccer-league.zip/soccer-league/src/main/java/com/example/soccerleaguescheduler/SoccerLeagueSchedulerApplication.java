package com.example.soccerleaguescheduler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoccerLeagueSchedulerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoccerLeagueSchedulerApplication.class, args);
	}
}
